
let plane;

function setup() {
  createCanvas(800, 600, WEBGL);
  plane = loadModel('plane.obj');
}

function draw() {
  background(0);
  ambientLight(100);
  normalMaterial();
  camera(350, -250, 200);
  scale(1, -1, 1);
  scale(0.3)
  translate(p5.Vector.fromAngle(millis() / 1000, 100));
  rotateX(millis() / 1000);
  rotateY(millis() / 1000);
  rotateZ(millis() / 1000);

  model(plane);
}
